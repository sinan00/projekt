package data;

public interface HospitalObserver {
    void notify(TemperaturlDTO temperaturlDTO);  //data transfor object
}
