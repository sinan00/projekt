import data.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

import java.io.IOException;

public class CollectorController implements HospitalObserver {
    public TextArea hospitalDataOutput;
    public TextField idField;  //id for flere hospitaler
    private boolean record;
    private HospitalDAO TemperaturDAO = new HospitalDAOSQLImpl();

    public void startDataCollection(ActionEvent actionEvent) {
        HospitalObservable hospitalStation = new HospitalDataGenerator();
        new Thread(hospitalStation).start();
        hospitalStation.register(this);



    }

    public void startRecording(ActionEvent actionEvent) {
        this.record= !this.record;
    }

    @Override
    public void notify(TemperaturlDTO temperaturlDTO) {
        //Show data
        String text = hospitalDataOutput.getText();
        text += "New Data! Time:"+ temperaturlDTO.getTime()+ ",Temperatur:" + temperaturlDTO.getTemperatur()+"\r\n";
        hospitalDataOutput.setText(text);
        //Save data
        if(this.record) {
            temperaturlDTO.setHospitalStationID(idField.getText());
            TemperaturDAO.save(temperaturlDTO);






        }

    }

    public void loadData(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/loadGUI.fxml"));
        try {
            FlowPane flowPane = fxmlLoader.load();
            Stage loadStage = new Stage();
            loadStage.setScene(new Scene(flowPane));
            loadStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }



    }
}
