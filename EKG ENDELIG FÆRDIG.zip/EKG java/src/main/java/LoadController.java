/** @author Yesim */
import data.EKGDAO;
import data.EKGDAOSQLImpl;
import data.SQLConnector;
import data.EKGDTO;
import javafx.event.ActionEvent;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.List;

public class LoadController {
    public DatePicker datePicker;
    public TextArea hospitalDataArea;

    public void LoadData(ActionEvent actionEvent) {
        LocalDateTime localDateTime = datePicker.getValue().atStartOfDay();
        Timestamp time = Timestamp.valueOf(localDateTime);
        EKGDAO ekgDAO = new EKGDAOSQLImpl();
        List<EKGDTO> load = ekgDAO.load(time);
        List <EKGDTO> ekgData = load;
        String text = "";
        for (EKGDTO data: ekgData) {
            text += "CPR:" + data.getCPRnummer()+ ",Time:" + data.getTime() + ",EKG:" + data.getEKGdata()+ "\r\n";
            
        }
        hospitalDataArea.setText(text);
    }
}
