/** @author Sinan,Irem */
import data.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class CollectorController<save> implements EKGObserver {
    public TextArea hospitalDataOutput;
    public TextField idField;  //id for flere hospitaler
    public LineChart<Integer, Integer> lineChart;
    XYChart.Series<Integer, Integer> series = new XYChart.Series<>();
    int x = 0;
    private boolean record;
    private EKGDAO EKGDAO = new EKGDAOSQLImpl();

    public void startDataCollection(ActionEvent actionEvent) throws InterruptedException {
        lineChart.getData().add(0,series);
        lineChart.setCreateSymbols(false);
        hospitalDataOutput.setText(String.valueOf(System.currentTimeMillis()));
        Threadmanager threadmanager = new Threadmanager(this);
        new Thread(threadmanager).start();
    }

    public void startRecording(ActionEvent actionEvent) {
        this.record = !this.record;
    }

    public void loadData(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/loadGUI.fxml"));
        try {
            FlowPane flowPane = fxmlLoader.load();
            Stage loadStage = new Stage();
            loadStage.setScene(new Scene(flowPane));
            loadStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void notify(LinkedList<EKGDTO> measurements) {
        //Show data
        String text = hospitalDataOutput.getText();

        text += "New Data! Time:" + System.currentTimeMillis() + ",EKG:" + measurements.get(0) + "\r\n";
        String finalText = text;
        System.out.println(finalText);
        Platform.runLater(new Runnable() {

            @Override
            public void run() {

                for (int i=0; i< measurements.size(); i++) {
                    series.getData().add(new XYChart.Data<Integer, Integer>(x, (int) measurements.get(i).getEKGdata()));
                    x++;
                    final int WINDOW_SIZE=1000;
                    if (x>WINDOW_SIZE) {
                        x=0;
                        series.getData().clear();

                    }

                }

            }
        });
        for (EKGDTO ekgdto:measurements
             ) {
            if (this.record){
                ekgdto.setCPRnummer(idField.getText());
                //EKGDAO.save(ekgdto);




            }
        }

        if (this.record) {
            EKGDAO.saveBatch(measurements);
        }


        }
    }

//Save data

