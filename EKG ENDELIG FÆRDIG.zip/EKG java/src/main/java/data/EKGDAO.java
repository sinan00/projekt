/** @author Sinan */
package data;

import java.sql.Timestamp;
import java.util.List;

public interface EKGDAO {
    void save(EKGDTO ekgDTO);
    void saveBatch(List<EKGDTO> list);

    List<EKGDTO> load(Timestamp time);
}
