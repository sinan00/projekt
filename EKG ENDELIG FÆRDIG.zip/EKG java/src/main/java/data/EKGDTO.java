/** @author Sinan */
package data;

import java.sql.Timestamp;

public class EKGDTO {
    private int id;
    private String ekgId;
    private String cprnummer;
    private double EKGdata;
    private Timestamp time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEKGId() {
        return ekgId;
    }

    public void setEKGId(String ekgId) {
        this.ekgId = ekgId;
    }

    public String getCPRnummer() {
        return cprnummer;
    }

    public void setCPRnummer(String cprnummer) {
        this.cprnummer = cprnummer;
    }

    public double getEKGdata() {
        return EKGdata;
    }

    public void setEKGdata(double ekgdata) {
        EKGdata = ekgdata;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }
}

