/** @author Irem */
package data;

import java.util.LinkedList;

public interface EKGObserver {
    void notify(LinkedList<EKGDTO> measurements);  //data transfor object
}
