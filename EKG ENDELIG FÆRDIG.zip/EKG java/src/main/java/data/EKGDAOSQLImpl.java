/** @author Irem */
package data;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EKGDAOSQLImpl implements EKGDAO {
    @Override
    public void save(EKGDTO ekgDTO) {
        Connection conn = SQLConnector.getConnection();
        try {
            PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO hospitalData(CPRnummer, EKGdata,  time) VALUES (?,?,?)"); {
                preparedStatement.setString(1, ekgDTO.getCPRnummer());
                preparedStatement.setDouble(2, ekgDTO.getEKGdata());
                preparedStatement.setTimestamp(3, ekgDTO.getTime());
                preparedStatement.execute();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void saveBatch(List<EKGDTO> list) {
        Connection conn= SQLConnector.getConnection();
        try {
            PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO hospitalData(CPRnummer, EKGdata, time) VALUES (?,?,?)");
            for (EKGDTO ekgdto: list)
            {
                preparedStatement.setString(1, ekgdto.getCPRnummer());
                preparedStatement.setDouble(2, ekgdto.getEKGdata());
                preparedStatement.setTimestamp(3, ekgdto.getTime());
                preparedStatement.addBatch();
            }
            preparedStatement.executeBatch();
        }
            catch (SQLException e){
                e.printStackTrace();
            }
        }


    @Override
    public List<EKGDTO> load(Timestamp time) {
        List <EKGDTO> data = new ArrayList<>();
        Connection connection = SQLConnector.getConnection();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM hospitalData WHERE time > ? limit 400");
            preparedStatement.setTimestamp(1,time);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                EKGDTO ekgDTO = new EKGDTO();
                ekgDTO.setId(resultSet.getInt("id"));
                ekgDTO.setCPRnummer(resultSet.getString("CPRnummer"));
                ekgDTO.setEKGdata(resultSet.getDouble("EKGdata"));
                ekgDTO.setTime(resultSet.getTimestamp("Time"));
                data.add(ekgDTO);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;

    }
    }

