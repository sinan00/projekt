/** @author Yesim */
package data;

import data.EKGObserver;

public interface EKGObservable extends Runnable { //interesseret i nye data
    void register (EKGObserver ekgObserver);
}
